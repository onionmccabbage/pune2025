import AddTransaction from "./AddTransaction";

const AddTransactionPage = () => {
    return (<div>
                <AddTransaction />
            </div>);
}

export default AddTransactionPage;
