const PageNotFound = () => {
    return(<h3>Sorry - that page doesn't exist</h3>);
}

export default PageNotFound
