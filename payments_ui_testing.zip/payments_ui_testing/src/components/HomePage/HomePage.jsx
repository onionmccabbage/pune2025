const HomePage = () => {
    return (<div><h3>Welcome to the Payments application.</h3></div>);
}

export default HomePage;
