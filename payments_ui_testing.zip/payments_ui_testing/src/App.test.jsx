import { render, screen } from '@testing-library/react';
import App from "./App";
import { expect, test, vi } from 'vitest';

vi.mock('./data/DataFunctions', () => {
    return {};
})

test('renders correctly', () => {
    render(<App />);
    const pa = screen.getByText("Payments Application");
    expect(pa).toBeInTheDocument();
});
