// copied from online then updated
import { NavLink, Outlet } from "react-router";

const MyAppNav = () => {
  return (
    <>
      <nav>
        {/* NavLink or Link (both work) */}
        <NavLink to="/" >
          Home
        </NavLink> | <NavLink to="/search" end>
          Search</NavLink> | <NavLink to="/transactions">
          Transactions</NavLink>
      </nav>
      <Outlet/>
    </>
  );
}
export default MyAppNav