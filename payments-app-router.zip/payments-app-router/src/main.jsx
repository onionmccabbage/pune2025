import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
// import for routing
import { BrowserRouter, Routes, Route } from "react-router";

import './index.css'
import App from './App.jsx'
// we import all the components we need to router to
import Search from './components/Search/Search.jsx';
import Transactions from './components/Transactions/Transactions.jsx';


// to convert to using routes:
// - npm install npm install react-router@latest

// change existing content of main.jsx to this:d
const root = document.getElementById("root");

createRoot(root).render(
  // remember to import BrowserRouter
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<App />} />
      <Route path="search" element={<Search />} />
      <Route path="transactions" element={<Transactions />} />
    </Routes>
  </BrowserRouter>,
);
