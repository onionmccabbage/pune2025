const Menu = () => {
    return (
        <ul className="nav">
            <li>Find a transaction</li>
            <li>New transaction</li>
        </ul>
    );
}

export default Menu;
